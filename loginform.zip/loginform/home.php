<?php

session_start();

?>

<html>
    <head>
        <title> Home Page</title>
    </head>
    
    <body>
        <h1> Welcome! You have successfully loged in. </h1>
    
    
    </body>



</html>